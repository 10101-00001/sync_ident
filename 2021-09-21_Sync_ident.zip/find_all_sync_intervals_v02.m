%% ***********************************************************************
% ***  find all sync intervals, using the R^2 matrix
% ***  input  : the R2 matrix (output of compute_WCLC or compute_WCLR)
% ***           time_lag_tolerance -> integer how much changes of time lag
%               allowed
% ***           minimum_length -> minimum length of an sync interval
% ***  output : list of sync intervals (losi) and list of peaks (lop)
% ***  losi: 1col = time lag,  2col = begin,  3col = end,  4col = mean(R2)
% ***  lop : 1col = time lag,  2col = begin,  
function [losi, lop_out] = ...
    find_all_sync_intervals_v02(R2, time_lag_tolerance, minimum_length)

    % proof the input
    if nargin < 3,
        minimum_length = 5;          % set a default value
        if nargin < 2,
            time_lag_tolerance = 1;  % set a default value
            if nargin < 1,
                error('R2 as input is needed.');
            end
        end
    end
    
    if minimum_length < 0 || minimum_length ~= round(minimum_length) || ...
            time_lag_tolerance < 0 || ...
            time_lag_tolerance ~= round(time_lag_tolerance),
        error(['time_lag_tolerance and minimum_length must be ', ...
               'positive integer.'])
    end
    

    % peak pick of R2
    [lop] = peak_picking_of_R2( R2 );
    
    %lop = [ 1 1 1; 2 1 1; 3 2 1; 4 2 1; 3 6 1; 6 6 1; 5 3 1; 6 3 1; 3 0 .5; ...
    %    7 2 1; -4 0 .5; -3 0 .5; -4 -3 .5; -3 -3 .2];  % list of peaks, for a test run

    % connect peaks given a time lag tolerance and a sync minimum length
    [losi] = connect_peaks( lop, time_lag_tolerance, minimum_length );
    
    % clear overlapping sync intervals
    [losi] = clear_overlapping_sync_intervals( losi );

    % prepare output
    if nargout == 2,
        lop_out = lop;
    end
    
    
%% ***********************************************************************
% ***  peak picking of R2
% ***  input  : R2 matrix, it is the output of compute_WCLC or compute_WCLR
% ***  output : lop = list of peaks
% ***  lop    : 1col = time point, 2col = time lag, 3col = peak height
function [lop] = peak_picking_of_R2( R2 )

    % proof input parameters
    if nargin < 1,
        error('R2 as input is necessary.');
    end
    
    % set variabels for work
    lop = [];
    
    % now, look for peaks for every t separately
    for t = 1:length( R2(:,1) ),
       
       pks = []; locs = [];
       [pks, locs] = findpeaks( R2( t, :));
       
       if ~isempty(pks),  % peaks found
           for k = 1:length(pks),
               lop = [ lop ; ...
                           [t locs(k) pks(k)] ];

           end
       end
    end


%% ***********************************************************************
% ***  connect peaks given a time lag tolerance and a sync minimum length
% ***  input  : list_of_peaks is the output of peak_picking_of_R2
% ***  output : losi = list of sync intervals
% ***  losi: 1col = time lag,  2col = begin,  3col = end,  4col = mean(R2)
function [losi] = connect_peaks( ...
                     list_of_peaks, time_lag_tolerance, minimum_length)

    % proof the input ************************************
    if nargin < 3,
        minimum_length = 5;   % set default
        if nargin < 2,
            time_lag_tolerance = 1; % set default
            if nargin < 1,
                error('list_of_peaks as input is necessary.');
            end
        end
    end

    if minimum_length < 1 || minimum_length ~= round(minimum_length),
        error('minimum_length must be an interger and larger than 0.');
    end
    
    if time_lag_tolerance < 0 || ...
             time_lag_tolerance ~= round(time_lag_tolerance),
        error(['time_lag_tolerance must be an interger ', ...
               'and larger than 0 or equal 0.']);
    end   

    % pre set *********************************************
    losi = [];
    
    % now, try to find the neighbour of a peak
    if ~isempty(list_of_peaks),
        
        % how many peaks?
        peaks_count = length( list_of_peaks(:,1));
        
        % at first, add a column with an case index
        list_of_peaks = [list_of_peaks [1:peaks_count]'];
        
        % now, find for every single peak the possible neighbours
        M = logical( zeros( peaks_count, peaks_count ) );
        
        for i = 1:peaks_count,
            
            % pre set
            list_of_neighbours = [];
            
            % give the reference peak the first place in the list
            lop = [list_of_peaks(i,:); ...
                   list_of_peaks( list_of_peaks(:,end) ~= i,:)];
            
            % find neighbours looking foreward and look backward
            list_of_neighbours = [list_of_neighbours ; ...
                find_neighbours_moving_foreward( lop, time_lag_tolerance) ; ...
                find_neighbours_moving_backward( lop, time_lag_tolerance) ];
            list_of_neighbours(end, :) = []; % delete the double element

            % save the result
             M( list_of_neighbours(:,end), i) = true;
             R2_mean(1, i) = mean( list_of_neighbours(:,3) );
             
        end
        
        % clear unused variables
        clear list_of_neighbours i j lop
        
        % filter too short sync intervals -> minimum_length
        indexM = sum( M ) < minimum_length;
        M(:, indexM ) = [];
        R2_mean(:, indexM ) = [];
        
        % sort the intervals regarding to their length and (subsequent) R2 mean
        [M2, indexM] =  sortrows( [sum( M ); R2_mean]' , [-1 -2] );
        clear M2
        M = M(:, indexM );
        R2_mean = R2_mean(:, indexM ); 
        clear indexM
        
        % delete sync intervals with double used elements
        new_M = [];
        new_R2_mean = [];
        while ~isempty(M),
            
            % save the largest sequence
            new_M = [new_M M(:,1)];
            M(:,1) = [];
            
            new_R2_mean = [new_R2_mean R2_mean(:,1)];
            R2_mean(:,1) = [];
            
            % find shorter sequences with the same elements
            index_row = new_M(:, end) == true;
            index_col = sum(M(index_row, :) == 1) > 0;
            M(:,index_col)=[];
            R2_mean(:,index_col) = [];

        end
        
        % save results as list of sync intervals (losi)
        % 1col = time lag,  2col = begin,  3col = end,  4col = mean(R2)
        for i = 1:length(new_R2_mean),
            
            losi(i,1) = round( mean( list_of_peaks(logical(new_M(:,i)), 2) )); % mean time lag
            losi(i,2) = min( list_of_peaks(logical(new_M(:,i)), 1) ); % begin of sequence
            losi(i,3) = max( list_of_peaks(logical(new_M(:,i)), 1) ); % end of sequence
            losi(i,4) = new_R2_mean(1,i);  % mean( R2)
            
        end
        
    end


%% ***********************************************************************
% ***  for the first run, use only the variables 
% ***          list_of_peaks, time_lag_tolerance, minimum_length  !!!
% ***  
function [list_of_neighbours, list_of_peaks_out] = ...
    find_neighbours_moving_foreward( ...
        list_of_peaks, time_lag_tolerance, list_of_neighbours, lag)

    % ***  proof input
    if nargin < 4,
        lag = 0;
        if nargin < 3,
            list_of_neighbours = [];
            if nargin < 2,
                error('Input is not complete.');
            end
        end
    end


    % ***  now, find neighbours 
    if ~isempty(list_of_peaks),
        
        % ***  first run
        if isempty(list_of_neighbours),
            
            % set the first element as orgin
            list_of_neighbours = list_of_peaks(1,:);
            
            % begin the next step
            [list_of_neighbours, list_of_peaks] = ...
                        find_neighbours_moving_foreward( list_of_peaks, ...
                        time_lag_tolerance, list_of_neighbours, lag);

        else % find the neighbours of the late entry in the list_of_neighbours
        
            % clear all peaks which are t or before t, which could not a neighbour
            list_of_peaks( ...
                    list_of_peaks(:,1) <= list_of_neighbours(end,1), :) = [];

            % which time lag changings allowed?
            [allowed_lags] = which_lags_are_allowed(lag, time_lag_tolerance);
                
            % find possible neighbours
            neighbour_index = [];
            for i = 1:length(allowed_lags),
                
                neighbour_index = [neighbour_index ; ...
                    find( ...
                        list_of_neighbours(end,1)+1 == list_of_peaks(:,1) & ...  
                        list_of_neighbours(end,2)+allowed_lags(i) == list_of_peaks(:,2) ) ];
            end

            if ~isempty(neighbour_index),  % if neighbours found ...

                % if neighbours, choose the one with the largest R2
                candidates = list_of_peaks(neighbour_index,:);
                candidates = candidates( ...
                    max(candidates( :, 3)) == candidates( :, 3),:);
                    
                % the impossible case of 2 maxima
                if length( candidates( :, 3) ) > 1,
                    candidates = candidates(1,:);
                end    


                % increase resp. decrease the "lag"
                lag = lag + candidates(1,2) - list_of_neighbours(end,2) ;

                % save new neighbour
                list_of_neighbours = [list_of_neighbours ; candidates ];
                
                % delete the neighbour in the peak list
                list_of_peaks( ...
                    list_of_peaks(:,1) == candidates(1,1) & ...
                    list_of_peaks(:,2) == candidates(1,2) & ...
                    list_of_peaks(:,3) == candidates(1,3) , : ) = [];

                % now, look for the next neighbour
                [list_of_neighbours, list_of_peaks] = ...
                    find_neighbours_moving_foreward( list_of_peaks, ...
                    time_lag_tolerance, list_of_neighbours, lag);
            end
        end
    end
    
    % prepare output
    if nargout == 2,
        list_of_peaks_out = list_of_peaks;
    end
    

%% ***********************************************************************
% ***  for the first run, use only the variables 
% ***          list_of_peaks, time_lag_tolerance, minimum_length  !!!
% ***  
function [list_of_neighbours, list_of_peaks_out] = ...
    find_neighbours_moving_backward( ...
        list_of_peaks, time_lag_tolerance, list_of_neighbours, lag)

    % ***  proof input
    if nargin < 4,
        lag = 0;
        if nargin < 3,
            list_of_neighbours = [];
            if nargin < 2,
                error('Input is not complete.');
            end
        end
    end


    % ***  now, find neighbours 
    if ~isempty(list_of_peaks),
        
        % ***  first run
        if isempty(list_of_neighbours),
            
            % set the first element as orgin
            list_of_neighbours = list_of_peaks(1,:);
            
            % begin the next step
            [list_of_neighbours, list_of_peaks] = ...
                        find_neighbours_moving_backward( list_of_peaks, ...
                        time_lag_tolerance, list_of_neighbours, lag);

        else % find the neighbours of the late entry in the list_of_neighbours
        
            % clear all peaks which are t or later, which could not a neighbour
            list_of_peaks( ...
                    list_of_peaks(:,1) >= list_of_neighbours(end,1), :) = [];

            % which time lag changings allowed?
            [allowed_lags] = which_lags_are_allowed(lag, time_lag_tolerance);
                
            % find possible neighbours regarding to the time lag
            neighbour_index = [];
            for i = 1:length(allowed_lags),
                
                neighbour_index = [neighbour_index ; ...
                    find( ...
                        list_of_neighbours(end,1)-1 == list_of_peaks(:,1) & ...  
                        list_of_neighbours(end,2)+allowed_lags(i) == list_of_peaks(:,2) ) ];
            end

            if ~isempty(neighbour_index),  % if neighbours found ...

                % if neighbours, choose the one with the largest R2
                candidates = list_of_peaks(neighbour_index,:);
                candidates = candidates( ...
                    max(candidates( :, 3)) == candidates( :, 3),:);
                    
                % the impossible case of 2 maxima
                if length( candidates( :, 3) ) > 1,
                    candidates = candidates(1,:);
                end    


                % increase resp. decrease the "lag"
                lag = lag + candidates(1,2) - list_of_neighbours(end,2) ;

                % save new neighbour
                list_of_neighbours = [list_of_neighbours ; candidates ];
                
                % delete the neighbour in the peak list
                list_of_peaks( ...
                    list_of_peaks(:,1) == candidates(1,1) & ...
                    list_of_peaks(:,2) == candidates(1,2) & ...
                    list_of_peaks(:,3) == candidates(1,3) , : ) = [];

                % now, look for the next neighbour
                [list_of_neighbours, list_of_peaks] = ...
                    find_neighbours_moving_backward( list_of_peaks, ...
                    time_lag_tolerance, list_of_neighbours, lag);
            end
        end
    end
    
    % prepare output
    if nargout == 2,
        list_of_peaks_out = list_of_peaks;
    end


%% ***********************************************************************
% *** it is a sub routine for find_neighbours_moving_foreward and
% *** find_neighbours_moving_backward
function [allowed_lags] = which_lags_are_allowed(lag, tolerance)

    % proof input
    if nargin < 2,
        error('Input is not complete.');
    end
    
    % *** pre set
    if tolerance == 0,
        allowed_lags = 0;
    else
        allowed_lags = [-1 0 1]';
        
        % *** lag should not be overrun the tolerance range
        if lag + 1 > abs(tolerance),  
            allowed_lags = [-1 0]';
        elseif lag - 1 < -1*abs(tolerance),
            allowed_lags = [ 0 1]';
        end
        
    end


%% ***********************************************************************
% ***  clear overlapping sync intervals
% ***  input : list of sync intervals (it is the output of connect_peaks)
% ***  output: list of sync intervals
function [losi_new] = clear_overlapping_sync_intervals( losi )

    % pre set
    losi_new = [];
    
    % now, look for overlapping intervals
    if ~isempty( losi ),
       
        % at first, add a column with the length  (it is the 5. coloumn)
        losi = [losi [losi(:,3)-losi(:,2)+1 ]];
        
        % add a column with distance to the zero line (means time lag = 0)
        % (it is the 6. coloumn)
        losi = [losi abs(losi(:,1))];

        % adjustment of the beginning with the time lag
        %losi(:,2) = losi(:,2) + losi(:,6);
        
        % sort by R2, distance to zero line, the length, and beginning
        % the best candidate is in first line, the badest in the last line
        losi = sortrows( losi, [-4 -6 -5 2] );
        
        % *** find overlapping intervals and delete the interval with the
        % *** smaller R2
        while ~isempty( losi ),
        
            % *** save the first line, because it is the best candidate
            losi_new = [losi_new ; losi(1,:) ];
            losi(1,:) = [];
            
            % *** compare with the bader candidates 
            candidates_to_delete = ...
                (losi(:,2) >= losi_new(end,2) & ...   % overlapping begin
                    losi(:,2) <= losi_new(end,3)) | ... 
                (losi(:,3) >= losi_new(end,2) & ...   % overlapping end
                    losi(:,3) <= losi_new(end,3)) ; %| ... 
                
            % *** delete
            losi(candidates_to_delete,:) = [];
                
        end
        
        % *** find overlying intervals and delete the interval with the
        % *** smaller R2
        losi = losi_new;
        losi_new = [];
        
        while ~isempty( losi ),
        
            % *** save the first line, because it is the best candidate
            losi_new = [losi_new ; losi(1,:) ];
            losi(1,:) = [];
            
            % *** compare with the bader candidates 
            candidates_to_delete = ...
                (losi(:,2) >= losi_new(end,2) & ...   % old is within new
                    losi(:,3) <= losi_new(end,3)) | ... 
                (losi(:,2) <= losi_new(end,2) & ...   % new is within old
                    losi(:,3) >= losi_new(end,3)) ; 
                
            % *** delete
            losi(candidates_to_delete,:) = [];
                
        end
        
        
        % delete the addional columns
        losi_new(:,5:6) = [];
        
    end







%% ***********************************************************************