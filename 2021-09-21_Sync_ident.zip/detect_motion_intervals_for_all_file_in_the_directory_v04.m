% detect motion intervals for all time series in the directory
function [] = detect_motion_intervals_for_all_file_in_the_directory_v04( ...
                search_string, working_dir_MEA, cut_off_for_motions)

    
    % check input parameters
    % if not given, replace with default values
    if nargin < 3
    
        % default cut off to distinguish motion (ME >= cut off) and not
        % motion (ME < cut off)
        % note: the default (1) expect ROI size standardizied motion energy 
        % time series with values ranging from 0 to 100
        cut_off_for_motions = 1.0; 
        
    end
    
    if nargin < 2
    
        disp(' ')
        disp('Please select the directory in which the motion energy files are stored.')
        
        working_dir_MEA = uigetdir;
        
    end
    
    if nargin < 1
    
        % default search string for motion energy time series
        % examples '*.txt' or '*MEA_co12_stand_vef_mm_lt.txt'
        % Note, this script expects log transformed time series! (indicated by "lt" in the file name)
        search_string = '*MEA_co12_stand_vef_mm_lt.txt';
        
    end

    
    
    % list of files with time series
    Names = dir(  fullfile( working_dir_MEA, search_string ) );  
    Names = {Names.name}';
    Names = char( fullfile( working_dir_MEA, Names) );
    
    n_files = length(Names(:,1));
    
    
    
    % Display some information
    disp(' ')
    disp(['Working directory:', working_dir_MEA])
    disp(' ')
    disp(['Found ', num2str(n_files), ' files using the search string: ', ...
          search_string])
    disp(' ')
    
    
    
    % create list of results       
    list_of_file_names = cell(n_files , 1) ;
    
    LOI_stats_all = NaN * ones( n_files, 4*7 );
    
    
    % do statistics for all file in the list
    for n = 1:n_files 
        
        % load MEA
        % in the sync age project, preprocessing steps like moving median
        % and log transformation are already applied
        M = dlmread( Names(n,:) );
        

        % split sting in path, file name and extension
        [~, name, ~] = fileparts( Names(n,:) );
        
        list_of_file_names{n,1} = name;
        
        
        % display some informations
        disp([ 'File ', num2str(n), ' of ', num2str(n_files), ...
               ': ', name])
        
        % reverse of log transformation of MEA so that
        % 0 = no motion, 100 = 100% of ROI = max. motion)        
        me(:,1) = exp(M(:,1)) - 1 ;  % body motions person 1 
        me(:,2) = exp(M(:,2)) - 1 ;  % body motions person 2
        me(:,3) = exp(M(:,5)) - 1 ;  % head motions person 1
        me(:,4) = exp(M(:,6)) - 1 ;  % head motions person 2
        
       
        
        % detect motion intervals
        LOI_stats = [ list_of_intervals_statistics( Detect_motion_intervals( me(:,1), cut_off_for_motions ) ) ...
                      list_of_intervals_statistics( Detect_motion_intervals( me(:,2), cut_off_for_motions ) ) ...
                      list_of_intervals_statistics( Detect_motion_intervals( me(:,3), cut_off_for_motions ) ) ...
                      list_of_intervals_statistics( Detect_motion_intervals( me(:,4), cut_off_for_motions ) ) 
                    ];
        
            
        % add individual statistics to list
        LOI_stats_all(n,:) = LOI_stats;
        
        
        % clear variables
        clear M me LOI_stats
        
        
    end % for

    
    
    % save results as excel tab
    % add the variable names in the 1st line
        % length of time series
        % number of movement intervals
        % movement frequency in movements per second
        % duration of movement intervals in seconds: average
        % size resp. surface of interval: average
        % motion energy maximum
        % speed of bursts (size divided by duration ): average
        % number of peaks within the motion interval: average    
    
    variable_names = {
        'B1_ts_len'
        'B1_N_bursts'
        'B1_mov_feq'
        'B1_len'
        'B1_size'
        'B1_speed'
        'B1_N_peaks'
        'B2_ts_len'
        'B2_N_bursts'
        'B2_mov_feq'
        'B2_len'
        'B2_size'
        'B2_speed'
        'B2_N_peaks'
        'H1_ts_len'
        'H1_N_bursts'
        'H1_mov_feq'
        'H1_len'
        'H1_size'
        'H1_speed'
        'H1_N_peaks'
        'H2_ts_len'
        'H2_N_bursts'
        'H2_mov_feq'
        'H2_len'
        'H2_size'
        'H2_speed'
        'H2_N_peaks'
        }';
    
    MIA_all = [ array2table(list_of_file_names, 'VariableNames', {'video_ID'}), ...
                array2table(LOI_stats_all, 'VariableNames', variable_names)      ];
    
    % save analyis results in excel sheet
    output_file_name = [working_dir_MEA '\' datestr(now, 'yyyy-mm-dd') '_list_of_movement_statistics.xls'];
    
    disp(' ')
    disp(['Save results in: ', output_file_name]);
    
    writetable( MIA_all, output_file_name );
    
end % function


% ************************************************************************
function LOI_stats = list_of_intervals_statistics( list_of_intervals )

    % proof input
    if nargin < 1
        
        error('Function list_of_intervals_statistics need the variable list_of_intervals as input.')

    end
    
    
    % create empty output vector
    LOI_stats = NaN * ones(1,7);

    
    % check special case: no movement intervals
    if isempty(list_of_intervals) | length( list_of_intervals(:,1) == 1 ) == 0
        
        LOI_stats(1) = 0; 
        LOI_stats(2) = 0;

    else
        
        % length of time series
        LOI_stats(1) = max( list_of_intervals(:,3) );
        
        % number of movement intervals
        LOI_stats(2) = length( list_of_intervals(:,1) == 1 );  
        
        % exclude intervals without movement 
        list_of_intervals = list_of_intervals(list_of_intervals(:,1) == 1,:); 
        
        % movement frequency in movements per second
        LOI_stats(3) = sum(  list_of_intervals(:,4) ) / LOI_stats(1) ;  
        
        % duration of movement intervals in seconds: average
        LOI_stats(4) = mean( list_of_intervals(:,4)  ) ;

        % size resp. surface of interval: average
        LOI_stats(5) = mean( list_of_intervals(:,5) );
        
        % speed of bursts (size divided by duration ): average
        LOI_stats(6) = mean( rdivide(list_of_intervals(:,5), ...
                              list_of_intervals(:,4)) );
        
        %  number of peaks within the motion interval: average
        LOI_stats(7) = mean( list_of_intervals(:,8) );
        
    end % if
    
end % function


% ************************************************************************
function [list_of_intervals] = Detect_motion_intervals(me, mu)
% Given a motion energy time series, this script detects intervals 
% without motion (ME < \mu) and with motion (ME >= \mu)
% For separation a threshold \mu is necessary.

% For each motion and non-motion interval statistics computed according to 
% Grammer et al (1999) Fuzziness of nonverbal courtship communication 
% unblurred by motion energy detection. Journal of personality and social 
% psychology, 77(3), 487. 

% Note, the following motion enery times series were tested, script runs 
% error free: me = [1]; me = [0]; me = [1 1]; me = [0 0]; 
% me = [0 0 0 0 0 1 1 1 1 1 0 0 1 ]; me = [1 1 1 0 0 0 0 0 1 1 1 1 1 0 0 ];


% ************************************************************************
% proof input parameter in general
if nargin~=2
    error('Two input parameter are needed: 1st motion energy time series and 2nd threshold mu.');
end

if ~isnumeric(me)
    error('The first parameter is not numeric. The motion energy time series (a numeric vector) is expected.');
end

if ~isnumeric(mu)
    error('The second parameter is not numeric. A threshold value is expected.');
end



% ************************************************************************
% proof input parameter me

% is motion energy time series empthy?
if isempty(me)
    error('The motion energy time series is empthy.');
end


% the dimensions of motion energy vector, and proof that it is a vector
s = size(me);

if ( length(s)~=2) || ( s(1)~=1 && s(2)~=1 ) 
    error('The motion energy must be given as vector (time points x 1).');
end



% ************************************************************************
% proof input parameter mu

if isempty(mu)
    error('The threshold mu must be given (e.g. set mu=1).');
end


s = size(mu);

if ~( s(1)==1 && s(2)==1 ) && length(s)==2
    error('The threshold mu must be a number, not an multidimensionl array (e.g. set mu=1).');
end 


if mu <1
    disp(' ')
    disp(['You set the threshold to mu=', num2str(mu),', \n ', ...
          'Please note that normally motion energy time series have \n ', ...
          'positive values including zero. With such threshold value \n ', ...
          'the entire time series is set as no motion time interval. \n ', ...
          'The script proceed. But you should check wheter is intended. \n ', ...
          'We recommend to set mu = 1 or a higher value.' ]);
end



% ************************************************************************
% some pre-processing

% reshape, if necessary
if s(1)==1
    me = reshape( me, [], 1);
end


% define time vector
t = (1:length(me))';


% define binary motion vector, which indicates with one and zero that
% me => threshold mu
me_bin = ( me>= mu);



% ************************************************************************
% separation of intervals, creates a list whereby 
% 1st column: motion interval (0 = no , 1 = yes),
% 2nd column: interval begin (resp corresponding frame number)
% 3rd column: interval end   (resp corresponding frame number)

list_of_intervals = [];

while ~isempty( me_bin )
    
    interval_value = me_bin(1);
    
    interval_begin = t(1);

    interval_end   = min( t(me_bin ~= interval_value) );

    if isempty( interval_end )
        interval_end = t(end);
    else
        interval_end = interval_end - 1;
    end
    
    
    % add new interval
    list_of_intervals = [list_of_intervals ; ...
                         interval_value interval_begin interval_end ];
                     
    
    % delete the detected interval from time series
    me_bin( t <= interval_end ) = [];
    t( t <= interval_end ) = [];
    
    
end % while

% deleted variables which no longer used 
clear interval_value interval_begin interval_end t me_bin;




% ************************************************************************
% computation of statistics about motion intervals in the list
% some columns added:
% 4th column: length of interval (end minus start)
% 5th column: size resp. surface of interval 
% 6th column: motion energy maximum
% 7th column: speed of bursts (size divided by duration ) 
% 8th column: number of peaks within the motion interval



% do it only, we have motion intervals ;)
if ~isempty(list_of_intervals)
    
    % 
    number_of_intervals = length( list_of_intervals(:,1) );
    
    
    % add column with zero values which later over write by statistics
    list_of_intervals(:,4:6) = 0;
    
    
    % compute statistics for each interval separatly
    for n = 1:number_of_intervals
        
        % 4th column: length of interval (end minus start)
        list_of_intervals(n,4) = list_of_intervals(n,3) - ...
                                 list_of_intervals(n,2) + 1;
        
                             
        % 5th column: size resp. surface of interval 
        list_of_intervals(n,5) = size_of_the_peaks( me, list_of_intervals(n,2), list_of_intervals(n,3), mu);
                
                
        % 6th column: motion energy maximum - mu
        list_of_intervals(n,6) = max( ...
                                 me(list_of_intervals(n,2): ...
                                    list_of_intervals(n,3) ) ) - mu ;
        
                
        % 7th column: speed of bursts (size divided by duration )
        list_of_intervals(n,7) = list_of_intervals(n,5) / ...
                                 list_of_intervals(n,4) ;
        
        
        % 8th column: number of peaks within the motion interval
        list_of_intervals(n,8) = number_of_peaks( ... 
                                    me(list_of_intervals(n,2): ...
                                    list_of_intervals(n,3) ) );
        
        
    end % for
    
    
end % if

end % function


% *************************************************************************
% sub-procedure: compute the number of peaks of the given time series
function [N_peaks] = number_of_peaks( ts )

    % proof input
    if nargin == 0
        error('Input parameter be missing (time series sequence which number of peaks should be computed).');
    end

    
    if ~isnumeric(ts)
        error('Input parameter must be a vector (time series sequence which number of peaks should be computed).');
    end
    
    % the dimensions of motion energy vector, and proof that it is a vector
    s = size(ts);
    if ( length(s)~=2) || ( s(1)~=1 && s(2)~=1 ) 
        error('The time series must be given as vector (time points x 1).');
    end    


          
    % compute ***********************************************************
    switch length( ts )
        case 0          % no data, no number of peaks

            N_peaks = NaN;

        case {1, 2}     % in this case only one peak is possble

            N_peaks = 1;

        otherwise
            
            % reshape as column vector and add a decrease at the end
            ts = [ reshape( ts, [], 1) ; ts(end)-1 ]; 
            
            % decrease from t_n to t_n+1 ?
            delta = (ts(2:end) - ts(1:end-1))' < 0; % decrease yes / no
            
            % count decreases with no decreases in the direct time points before 
            N_peaks = sum( ...
                        (delta(1:end)'==1) & ~([0 ; delta(2:end)' == delta(1:end-1)']) );

    end    % switch
    
end % function



% *************************************************************************
% sub-procedure: compute size of a peak
function [peak_size] = size_of_the_peaks( me, peak_b, peak_e, mu)

    % proof input
    if nargin < 4
        error('Input parameter be missing: 1st complete Motion energy time series, 2nd begin of peak, 3rd end of peak, and 4th threshold mu');
    end
   
    if (peak_b > peak_e) || (peak_e > length(me)) ||  (peak_b<1)
        error('Paramter begin of peak (2nd) and end of peak (3rd) are wrong. Both indicate element numbers of Motion energy time series, whereby begin < end.');
    end
    
    
    % compute size ******************************************************
    if peak_b == peak_e
        
        % special case, interval inlcudes only one short peak
        peak_size = me(peak_b) - mu;
        
    else
        
        % compute part of time series which of interest
        ts = reshape( me(peak_b:peak_e), [], 1) - mu;
        
        
        % amount of change from t_n to t_n+1
        delta  = [(ts(2:end) - ts(1:end-1)) ; ts(end) * -1];  

        
        % categorization of change: 1st column increase, 2nd decrease, 3rd
        % constant / no change
        change = [ delta>0 delta<0 delta==0 ];  
        

        % compute peak size as sum of special cases:
        peak_size = ts(1) * 0.5 + ...                                              % triangle at beginning of interval
                    sum( ts(change(:,1)==1) ) + 0.5 * sum( delta(change(:,1)==1) ) + ... % increase
                    sum( ts(change(:,3)==1) ) + ...                                % no change / constant
                    sum( ts(change(:,2)==1) ) + 0.5 * sum( delta(change(:,2)==1) ); % decrease including triangle at end of interval
        
                
        % alternative
        %peak_size = polyarea( [0; ts; 0; 0], [0; (1:length(ts))'; length(ts) + 1; 0]);
                
    end % if

end % function






