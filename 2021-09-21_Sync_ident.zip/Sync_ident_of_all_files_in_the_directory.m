%% written and developed by Uwe Altmann
%% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6

%% *********************************************************************
% The script searches for files with motion energy time series in a given 
% directory and apply WCLC / WCLR on it. Then it run the peak picking
% algorithm. At last all resultsing LOSI files were used to create a table
% with synchrony measures for all motion energy time series piars found in
% the directory.

function [] = Sync_ident_of_all_files_in_the_directory(directory_name)


%% *********************************************************************
%  parameter settings

% files
video_format = 'MEA_co12_stand_vef_mm_lt.txt';  % default is 'MEA_co12_stand_vef_mm_lt.txt' -> MEA with cut off=12 & standardization & video errors filtered & moving median & log transformation


% split data file if time series is "too" long. This avoids errors due to memory
% overflow in peak picking. If the error message still occurs, then use 
% the value 1500 (instead of 3000).
size_of_time_series_part = 3000; % default = 3000; 


% windowed cross-lagged correlation / regression

% WCLC or WCLR
method = 'WCLC'; % use 'WCLR' or 'WCLC' (default)

% set bandwidth to 125 frames (= 5 seconds if 25 fps)
bandwidth = 125; % recommanded resp. default is 125

% set maximum time lag to 5 seconds (= 125 frames if 25 fps)
max_lag = 125; % recommanded resp. default is 125

% calculate WCLR/WCLC in steps of 1
step = 2; % default is 2

% add_noise = true to avoid convergence problems with respect to the WCLR
add_noise = true;




% peak picking: minimum length of a sync interval. 10 is recommended. Given 
% 25fps, 10 means 0.4sec.
minimum_length = 10; % default = 10 

% peak picking: When connecting peaks if R2-matrix. You can choose: all 
% peaks of a specific interval must have the same time-lag, which means
% tolerance = 0. Or the peaks can hace slidly different time-lag, e.g.
% tolerance = 1. The latter is recommanded.
time_lag_tolerance = 1; % default is 1




%% *********************************************************************
%  check input arguments and select directory per hand if necessary

    % check input arguments: file name? If no, select with file browser
    if nargin<1 || isempty(directory_name) 

        disp(' ')
        disp('Please select the directory in which the motion energy files are stored.')
        
        directory_name = uigetdir;
        
    else
    
        if exist( directory_name, 'dir') ~= 7
            
            error(['The specified directory (' directory_name ...
                   ') is not a folder or does not exist.'])
        
        end
        
    end
    
    disp(' ')
    disp(['Selected directory is ' directory_name])
    disp(' ')

    
    % WCLC / WCLC
    method = upper( method );
    
    if ~(strcmp(method,'WCLC') || strcmp(method,'WCLR') )
        
        error('Unknown value of the parameter method. It must be WCLC or WCLR.');
        
    end
    
    
    
    

%% *********************************************************************
% liste der motion energy time series pairs erstellen

    if isempty(video_format)
        
        disp(' ')
        error('The variable video_format is empthy, please specify a search string.')
        
    elseif video_format(1)~='*'
        
        video_format = ['*' video_format];
        
    end
    
    Names = dir( fullfile(directory_name, video_format) );
    Names = {Names.name}';
    Names = fullfile(directory_name, Names);

    n_videos = length(Names);
    
    disp(' ')
    disp(['Found ' num2str(n_videos) ' files.'])




%% *********************************************************************

    for n = 1:n_videos
        
        % set timer for stop watch
        tic ;
        
        % load data
        disp(' ')
        disp( strcat( 'Load time series file ' , ...
                      '(', ...
                      num2str(n), ...
                      ' of ', ...
                      num2str(n_videos), ...
                      '): ', ...
                      Names{n} ));

        
         Sync_ident_one_large_file( Names{n}, ...
                  method, bandwidth, max_lag, step, ...
                  minimum_length, time_lag_tolerance, ...
                  size_of_time_series_part )     
         
         calculation_time = toc;
         
         
         disp(' ')
         disp( strcat('Calculation time for this time series pair: ', ...
                      num2str( round(calculation_time, 1) ), ...
                      'sec (respectively ', ...
                      num2str( round(calculation_time/60, 1) ), ...
                      'min respectively ', ...
                      num2str( round(calculation_time/60/60, 1) ), ...
                      'h)' ...
                      ) )
         
         
    end % for

    disp(' ')
    disp('Done. All time series files in the directory are analysed.');
    disp(' ')
