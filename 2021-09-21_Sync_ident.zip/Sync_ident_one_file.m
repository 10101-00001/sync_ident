%% written and developed by Uwe Altmann
%% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6

%% *********************************************************************
% The script apply WCLC / WCLR on motion energy time series file. 
% Then it run the peak picking algorithm. 
% The list of sync intervals (LOSI) of this file / time series pair is saved in
% the directory.

% All input parameter are optional. If no parameter was specified, the
% script open a graphical user interface to select a txt file with the
% motion energy time series (output of the script MEA_and_preprocessing_of_a_video.m or 
% MEA_and_preprocessing_of_a_directory.m). All other parameter set to default  
% values which recommended by Schoenherr et al. (2019, PLOSONE).

% The algorithm and the parameter are briefly described in Altmann (2011) [english] and in 
% detail in Altmann (2013) [german].


function [] = Sync_ident_one_file(video_file_name, ...
                  method, bandwidth, max_lag, step, minimum_length, time_lag_tolerance )


%% *********************************************************************
%  parameter settings
    % windowed cross-lagged correlation (WCLC) or regression (WCLR)?
    if nargin<2 
        method = 'WCLC'; % use 'WCLR' or 'WCLC' (default)
    end

    % set bandwidth to 125 frames (= 5 seconds if 25 fps)
    if nargin<3
        
        bandwidth = 125; % recommanded resp. default is 125
        
    end

    % set maximum time lag to 5 seconds (= 125 frames if 25 fps)
    if nargin<4
        
        max_lag = 125; % recommanded resp. default is 125
        
    end

    % calculate WCLR/WCLC in steps of 1
    if nargin<5
        
        step = 2; % default is 1
        
    end

    % peak picking - minimum length of a sync interval, shorter interval we be
    % ignored
    if nargin<6
        
        minimum_length = 10; % 10 is recommended
        
    end

    % peak picking - within a sync interval window A predicts window B with a
    % stable time interval. time_lag_tolerance defines "stable". The default is
    % 1 which means that the time lags at t and t+1 can be differ be one unit.
    if nargin<7
        
        time_lag_tolerance = 1; % default is 1
        
    end




%% *********************************************************************
% check input arguments: file name? If no, select with file browser

    if nargin<1 || isempty(video_file_name) 

        disp(' ')
        disp('Please select the file which should be analysed.')
        disp('If you have applied the MEA with default values the file name should be *MEA_co12_stand_vef_mm_lt.txt .')
        
        [filename, PathName, ~] = uigetfile('*.txt');
    
        video_file_name = [PathName filename];   
        
    end

    
%% *********************************************************************
% WCLC / WCLC


    method = upper( method );
    
    if ~(strcmp(method,'WCLC') || strcmp(method,'WCLR') )
        
        error('Unknown value of the parameter method. It must be WCLC or WCLR.');
        
    end

    % add_noise = true to avoid convergence problems with respect to the WCLR
    add_noise = false;
        
    if strcmp(method,'WCLR') 
        
        add_noise = true;
        
    end
    
    
    
    
    
%% *********************************************************************
        
    % load data
    disp(' ')
    disp( strcat('Load time series file ', video_file_name ) );

    data = dlmread( video_file_name );

    time_series_length = length(data(:,1));

    t = (1:time_series_length)';



    % WCLC / WCLR
    switch method
        
        case 'WCLC'  % WCLC

            disp(' ')
            disp('Compute R2 with WCLC - body motions');

            R2_body = compute_WCLC(...
                        [t data(:,1:2)], ...
                        bandwidth, step, max_lag, add_noise);           

            disp(' ')
            disp('Compute R2 with WCLC - head motions');

            R2_head = compute_WCLC(...
                        [t data(:,5:6)], ...
                        bandwidth, step, max_lag, add_noise);   


        case 'WCLR'  % WCLR 

            disp(' ')
            disp('Compute R2 with WCLR - body motions');

            R2_body = compute_WCLR(...
                        [t data(:,1:2)], ...
                        bandwidth, step, max_lag, add_noise);           

            disp(' ')
            disp('Compute R2 with WCLR - head motions');

            R2_head = compute_WCLR(...
                        [t data(:,5:6)], ...
                        bandwidth, step, max_lag, add_noise);   

    end



    % peak picking
    disp(' ')
    disp('Applying peak picking algorithm on R2 matrix - body motions.');

    [losi_body] = find_all_sync_intervals_v02(R2_body, time_lag_tolerance, minimum_length);


    disp(' ')
    disp('Applying peak picking algorithm on R2 matrix - head motions.');

    [losi_head] = find_all_sync_intervals_v02(R2_head, time_lag_tolerance, minimum_length);


    % convert time lag according to step-parameter, 
    % e.g. 1, 2, 3, 4, 5 -> -2, -1, 0, 1, 2
    Y_axis_time = [ -max_lag:step:-step, 0, step:max_lag ] ;

    % convert body LOSI
    if ~isempty( losi_body )
        
        % convert time lag
        losi_body(:,1) = Y_axis_time( losi_body(:,1) ) ;
        
        % convert time point according to step-parameter and bandwidth 
        losi_body(:,2:3) = losi_body(:,2:3)*step + fix( bandwidth /2 );
        
        disp(' ')
        disp(['Body LOSI contains ' ...
              num2str( length( losi_body(:,1) ) ) ...
              ' sync-interval(s).'])

    else
        
        disp(' ')
        disp('The body LOSI is empty.')
        
    end
    

    % convert head LOSI
    if ~isempty( losi_head )
        
        % convert time lag
        losi_head(:,1) = Y_axis_time( losi_head(:,1) ) ;
        
        % convert time point according to step-parameter and bandwidth 
        losi_head(:,2:3) = losi_head(:,2:3)*step + fix( bandwidth /2 ) ;
        
        disp(' ')
        disp(['The head LOSI contains ' ...
              num2str( length( losi_head(:,1) ) ) ...
              ' sync-interval(s).'])

    else
        
        disp(' ')
        disp('The head LOSI is empty.')
        
    end
    
    
    % save list of sync intervals (LOSI)
    disp(' ')
    disp('Save both lists of sync intervals (LOSI).');
    disp(' ')

    [data_file_path, data_file_name, ~] = fileparts( char( video_file_name) ) ;
    
    save( strcat(data_file_path, '\', data_file_name, '_losi.mat'), ...
         'data_file_name', ...
         'time_series_length', ...
         'method', 'bandwidth', 'max_lag', 'step', ...
         'minimum_length', 'time_lag_tolerance', ...
         'losi_body', 'losi_head' );


