%% written and developed by Uwe Altmann
%% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6

%  The identification of synchronisation interval is conducted in several
%  steps, e.g. preprocessing of time series, WCLC, peak-picking algorithm
%  and analysis of LOSI. In the current form (Sep. 2021) peak-picking  
%  algorithm is memory intensive so that the identification of 
%  synchronisation intervals ends for long time series with an error
%  message respectively without a result.
%  This script can conduct an identification of synchronisation interval on
%  long time series. It split the time series in parts. Identifiy the sync
%  intervals in the parts and merge the list of sync intervals which is the
%  requested list for the large time series. Note that the overlap of time
%  series parts is equal to bandwidth of WCLC/WCLR.
%  After splitting the lond time series, the existing script for the 
%  identification of synchronisation intervals are used.


function [] = Sync_ident_one_large_file(video_file_name, ...
                  method, bandwidth, max_lag, step, ...
                  minimum_length, time_lag_tolerance, ...
                  size_of_time_series_part)

    
    
    
%% *********************************************************************
%  parameter settings
    % windowed cross-lagged correlation (WCLC) or regression (WCLR)?
    if nargin<2 
        method = 'WCLC'; % use 'WCLR' or 'WCLC' (default)
    end

    % set bandwidth to 125 frames (= 5 seconds if 25 fps)
    if nargin<3 
        
        bandwidth = 125; % recommanded resp. default is 125
        
    end

    % set maximum time lag to 5 seconds (= 125 frames if 25 fps)
    if nargin<4
        
        max_lag = 125; % recommanded resp. default is 125
        
    end

    % calculate WCLR/WCLC in steps of 1
    if nargin<5
        
        step = 2; % default is 2
        
    end

    % peak picking - minimum length of a sync interval, shorter interval we be
    % ignored
    if nargin<6
        
        minimum_length = 10; % 10 is recommended
        
    end

    % peak picking - within a sync interval window A predicts window B with a
    % stable time interval. time_lag_tolerance defines "stable". The default is
    % 1 which means that the time lags at t and t+1 can be differ be one unit.
    if nargin<7
        
        time_lag_tolerance = 1; % default is 1
        
    end

              
    % split too large time series
    if nargin<8

            size_of_time_series_part = 3000; % default = 3000; 
            
    end



%% *********************************************************************
% check input arguments: file name? If no, select with file browser

    if nargin<1 || isempty(video_file_name) 

        disp(' ')
        disp('Please select the file which should be analysed.')
        disp('If you have applied the MEA with default values the file name should be *MEA_co12_stand_vef_mm_lt.txt .')
        
        [filename, PathName, ~] = uigetfile('*.txt');
    
        video_file_name = [PathName filename];   
        
    end

    
%% *********************************************************************
% check: WCLC or WCLC


    method = upper( method );
    
    if ~(strcmp(method,'WCLC') || strcmp(method,'WCLR') )
        
        error('Unknown value of the parameter method. It must be WCLC or WCLR.');
        
    end
    
    
    
%% *********************************************************************
% load data

    disp(' ')
    disp(['Load time series file ' video_file_name]);

    data = dlmread( video_file_name );

%% *********************************************************************
% compute beginning and end of time series parts

    % length of original time series
    time_series_length = length(data(:,1));
    
    % number of parts (eventually plus one) 
    N_parts_ratio = time_series_length / size_of_time_series_part ;
    
    if N_parts_ratio <= 1
        
        parts_begin_n_end = [1 , time_series_length ];
        
    else
        
        % beginning (1st column) and end (2nd column) of time series parts
        parts_begin_n_end = [(0:(N_parts_ratio-1))'*size_of_time_series_part - bandwidth, ... 
                             (1:N_parts_ratio)'    *size_of_time_series_part];

        % handle the "rest"
        if N_parts_ratio - floor(N_parts_ratio) <0.5 

            % add rest to the last part
            parts_begin_n_end( end , 2) = time_series_length;

        else

            % rest is "too long" and handled as additional part (floor(N_parts_ratio) plus one)
            parts_begin_n_end(floor(N_parts_ratio)+1,1:2) = ...
                [ floor(N_parts_ratio)*size_of_time_series_part - bandwidth, ...
                  time_series_length ];

        end

        parts_begin_n_end(1,1) = 1; % begin of first part is always 1
    
    end
    
    N_parts = length( parts_begin_n_end(:,1) );
    

    
    
    
%% *********************************************************************
%  save the parts as separte files

    % create file names 
    parts_list_of_file_names = strings( N_parts, 1 );
    
    [data_file_path, data_file_name, data_file_suffix] = fileparts( char(video_file_name) ) ;
    
    parts_dec_num = ceil(log10(time_series_length));
    
    for n = 1:N_parts
        
        parts_list_of_file_names(n) = strcat( data_file_path, ...
                                              '\', ...
                                              'temp_', ...
                                              num2str( parts_begin_n_end(n,1), strcat('%0', num2str(parts_dec_num), 'd')), ...
                                              '_', ...
                                              num2str( parts_begin_n_end(n,2), strcat('%0', num2str(parts_dec_num), 'd')), ...
                                              '__', ...
                                              data_file_name, ...
                                              data_file_suffix);
        
    end

    disp(' ')
    disp('The time series is splitted into the following parts (the file name includes the start and end point):')
    disp(parts_list_of_file_names)
    
    
    % save time series parts
    for n = 1:N_parts
        
        dlmwrite( parts_list_of_file_names(n), ...
            data( parts_begin_n_end(n,1):parts_begin_n_end(n,2), :), ...
            '\t'); 
        
    end
    
    
    % conduct sync_ident with time series parts
    for n = 1:N_parts
        
        Sync_ident_one_file(parts_list_of_file_names(n), ...
                  method, bandwidth, max_lag, step, minimum_length, time_lag_tolerance );
              
    end
    
    
    % load and merge all LOSI and delete double entries
    disp(' ');
    disp('Merge LOSI of time series parts.');
    disp(' ');
    
    losi_body_all = [];
    losi_head_all = [];
    
    for n = 1:N_parts
        
        % file name of losi file
        [data_file_path, data_file_name, ~] = fileparts( char( parts_list_of_file_names(n) ) ) ;
        
        
        % load 
        load( strcat( data_file_path, ...
                      '\', ...
                      data_file_name, ...
                      '_losi.mat'), ...
              'losi_body', ...
              'losi_head');
        
        
        % correct start & end of sync intervals with starting point of time series part
        
        if ~isempty( losi_body )
            
            losi_body(:,2:3) = losi_body(:,2:3) + ...
                               parts_begin_n_end(n,1) - 1;
                           
        end
        
        
        if ~isempty( losi_head )
            
            losi_head(:,2:3) = losi_head(:,2:3) + ...
                               parts_begin_n_end(n,1) - 1; 
                           
        end
          

        % merge
        losi_body_all = [ losi_body_all ; losi_body ]; %#ok<AGROW>
        losi_head_all = [ losi_head_all ; losi_head ]; %#ok<AGROW>
        
    end
    
        
    % detect and delete double entries in the overall LOSI
    % body
    if ~isempty( losi_body_all )
        
        losi_body_all(:,5) = losi_body_all(:,3) - losi_body_all(:,2); % duration
        losi_body_all = sortrows( losi_body_all, 5 ); % sort by duration

        [~, ai] = unique( losi_body_all(:,1:2), 'rows', 'last' ); % identify unique entries, pickup these with largest duration
        losi_body_all = losi_body_all( ai, 1:4 ); % only unique entries and delete last column with duration
    
    end

    losi_body = losi_body_all ;
    
    
    % head
    if ~isempty( losi_head_all )
        
        losi_head_all(:,5) = losi_head_all(:,3) - losi_head_all(:,2);
        losi_head_all = sortrows( losi_head_all, 5 );

        [~, ai] = unique( losi_head_all(:,1:2), 'rows', 'last' );
        losi_head_all = losi_head_all( ai, 1:4 ); % only unique entries and delete last column with duration

    end
    
    losi_head = losi_head_all;
    
    
    
    % delete temporary data files
    disp(' ')
    disp('Delete temporary data files.');
    disp(' ')
    
    for n = 1:N_parts
        
        % data file of the part
        delete( parts_list_of_file_names(n) ); 
        
        
        % LOSI file of the part
        [data_file_path, data_file_name, ~] = fileparts( char( parts_list_of_file_names(n) ) ) ;
        
        delete( strcat( data_file_path, ...    
                      '\', ...
                      data_file_name, ...
                      '_losi.mat') );      
    end
    
    
    
    % save the merged list of sync intervals ("overall" LOSI)
    disp(' ')
    disp('Calculations done. Save merged list of sync intervals (LOSI).');
    disp(' ')

    [data_file_path, data_file_name, ~] = fileparts( char( video_file_name ) ) ;
    
    save( strcat(data_file_path, '\', data_file_name, '_losi.mat'), ...
         'data_file_name', ...
         'time_series_length', ...
         'method', 'bandwidth', 'max_lag', 'step', ...
         'minimum_length', 'time_lag_tolerance', ...
         'losi_body', 'losi_head' );