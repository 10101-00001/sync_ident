%% written and developed by Uwe Altmann
% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6
% Version from 21 September 2021


function [] = Merge_all_LOSI_files_in_the_directory(directory_name, R2_cut_off)


%% *********************************************************************
%  parameter settings

% files
video_format = 'losi.mat';  % default is 'losi.mat'


%% *********************************************************************
%  check input arguments and select directory per hand if necessary

    % check input arguments: file name? If no, select with file browser
    if nargin<1 || isempty(directory_name) 

        disp(' ')
        disp('Please select the directory in which the LOSI files are stored.')
        
        directory_name = uigetdir;
        
    else
    
        if exist( directory_name, 'dir') ~= 7
            
            error(['The specified directory (' directory_name ...
                   ') is not a folder or does not exist.'])
        
        end
        
    end
    
    disp(' ')
    disp(['Selected directory is ' directory_name])
    disp(' ')


    % check input arguments: R2 cut off introduced by Schoenherr et al.
    % (2019) PLOSONE, doi: 10.1371/journal.pone.0211494

    if nargin<2 

        R2_cut_off = 0.25; % default = 0.25 suggested by Schoenherr et al. (2019) PLOSONE
        
        disp(' ')
        disp('Applying R2 cut off = 0.25 as suggested by Schoenherr et al. (2019) PLOSONE.')
        
    else
        
        disp(' ')
        disp(['R2 cut off = ', num2str(R2_cut_off)] )
        
    end
    
    
    
    
%% *********************************************************************
% liste der LOSI Dateien erstellen

    if isempty(video_format)
        
        disp(' ')
        error('The variable video_format is empthy, please specify a search string.')
        
    elseif video_format(1)~='*'
        
        video_format = ['*' video_format];
        
    end
    
    Names = dir( fullfile(directory_name, video_format) );
    Names = {Names.name}';
    Names = fullfile(directory_name, Names);

    n_videos = length(Names);
    
    disp(' ')
    disp(['Found ' num2str(n_videos) ' files.'])




%% *********************************************************************
% losi laden und Kennwerte berechnen

    stats = zeros( n_videos, 18);  
    
    list_of_file_names = cell( n_videos, 1);

    for n = 1:n_videos
        
        % store directory, file name and file suffix in separate variables
        [~, data_file_name, ~] = fileparts( char( Names{n} ) );
        
        
        % load data
        disp(' ')
        disp(' ')
        disp(['Load LOSI file ' ...
              '(' num2str(n) ' of ' num2str(n_videos) ...
              '): ' Names{n}]);

        load( Names{n} , 'data_file_name', ...
             'time_series_length', ...
             'losi_body', 'losi_head');
        
        
        % body
        if ~isempty( losi_body )
             
            % applying R2 cut off according to Schoenherr et al 2019 PLOSONE
            losi_body( losi_body(:,4) < R2_cut_off, : ) = [];

            % duration of sync intervals
            losi_body(:,5) = losi_body(:,3) - losi_body(:,2);

            % average correlation of sync intervals
            losi_body(:,6) = sqrt( losi_body(:,4) );
            
        end
        
       
        % head
        if ~isempty( losi_head )        
            
            losi_head( losi_head(:,4) < R2_cut_off, : ) = [];
            
            losi_head(:,5) = losi_head(:,3) - losi_head(:,2);
            
            losi_head(:,6) = sqrt( losi_head(:,4) );  
        
        end
        
        
        % leangth of time series
        stats(n, 1) = time_series_length;      
        
        
        
        
        % --- BODY ---
        disp(' ')
        disp('Compute statistics about synchronisation using LOSI - body')
        
        
        if ~isempty( losi_body )  
            
            % sync total
            stats(n, 2) = sum( losi_body(:, 3) - losi_body(:, 2) ) / time_series_length * 100;

            % sync person 1 lead
            stats(n, 3) = sum( losi_body( losi_body(:,1) > 0, 3) - losi_body(losi_body(:, 1) > 0, 2) ) / time_series_length * 100;

            % sync person 2 lead
            stats(n, 4) = sum( losi_body( losi_body(:,1) < 0, 3) - losi_body(losi_body(:, 1) < 0, 2) ) / time_series_length * 100;

            % leading (sync person 1 lead minus sync person 2 lead)
            stats(n, 5) = stats(n, 3) - stats(n, 4) ;


            % number of sync intervals total
            stats(n, 6) = length( losi_body(:, 1) );

            % number of sync intervals total person 1 lead
            stats(n, 7) = length( losi_body(losi_body(:, 1) > 0, 1) );

            % number of sync intervals total person 2 lead
            stats(n, 8) = length( losi_body(losi_body(:, 1) < 0, 1) );


            % time lag (tau): weighted average relative to duration of sync intervals
            stats(n, 9) = sum( abs(losi_body( :, 1)).* losi_body(:,5) ) / ...
                sum( abs(losi_body( :, 5)) );

            % time lag (tau): range 
            stats(n,10) = max( abs(losi_body( :, 1)) ) - min( abs(losi_body( :, 1)) );


            % R2: weighted average relative to time series length
            stats(n,11) = sum( abs(losi_body( :, 4)).* losi_body(:,5) ) / ...
                time_series_length;

            % R2: weighted average relative to sync duration
            stats(n,12) = sum( abs(losi_body( :, 4)).* losi_body(:,5) ) / ...
                sum( abs(losi_body( :, 5)) );

            % abs(r): weighted average relative to time series length
            stats(n,13) = sum( abs(losi_body( :, 6)).* losi_body(:,5) ) / ...
                time_series_length;

            % R2: weighted average relative to sync duration
            stats(n,14) = sum( abs(losi_body( :, 6)).* losi_body(:,5) ) / ...
                sum( abs(losi_body( :, 5)) );
        
        end
        
        
        
        % --- HEAD ---
        disp(' ')
        disp('Compute statistics about synchronisation using LOSI - head')
        
        
        if ~isempty( losi_head )
            
            % sync total
            stats(n,15) = sum( losi_head(:, 3) - losi_head(:, 2) ) / time_series_length * 100;

            % sync with leading person 1
            stats(n,16) = sum( losi_head( losi_head(:,1) > 0, 3) - losi_head(losi_head(:,1) > 0, 2) ) / time_series_length * 100;

            % sync with leading person 2
            stats(n,17) = sum( losi_head( losi_head(:,1) < 0, 3) - losi_head(losi_head(:,1) < 0, 2) ) / time_series_length * 100;

            % leading 
            stats(n,18) = stats(n, 16) - stats(n, 17) ;

            % number of snyc intervals total
            stats(n,19) = length( losi_head(:, 1) );

             % number of snyc intervals person 1
            stats(n,20) = length( losi_head(losi_head(:, 1) > 0, 1) );

             % number of snyc intervals person 2
            stats(n,21) = length( losi_head(losi_head(:, 1) < 0, 1) );


            % time lag (tau): weighted average relative to duration of sync intervals
            stats(n,22) = sum( abs(losi_head( :, 1)).* losi_head(:,5) ) / ...
                sum( abs(losi_head( :, 5)) );

            % time lag (tau): range 
            stats(n,23) = max( abs(losi_head( :, 1)) ) - min( abs(losi_head( :, 1)) );

            % R2: weighted average - relative to time series length
            stats(n,24) = sum( abs(losi_head( :, 4)).* losi_head(:,5) ) / ...
                time_series_length;

            % R2: weighted average - relative to sync duration
            stats(n,25) = sum( abs(losi_head( :, 4)).* losi_head(:,5) ) / ...
                 sum( abs(losi_head( :, 5)) );

            % abs(r): weighted average - relative to time series duration
            stats(n,26) = sum( abs(losi_head( :, 6)).* losi_head(:,5) ) / ...
                time_series_length;

            % abs(r): weighted average - relative to sync duration
            stats(n,27) = sum( abs(losi_head( :, 6)).* losi_head(:,5) ) / ...
                 sum( abs(losi_head( :, 5)) );
         
        end
        
        
        
        %
        list_of_file_names{n} = data_file_name;
        
        
        %
        clear data_file_name time_series_length  ...
              losi_body losi_head ;
        
    end % for

    
%% *********************************************************************
% Dateinamen und Statistken in einer Tabelle zusammenfassen

Tab1 = cell2table(list_of_file_names , 'VariableNames', {'file_name'});

Tab2 = array2table(stats, ...
            'VariableNames', ...
                {'time_series_length', ...
                 'sync_total_b', ...
                 'sync_p_lead_b', ...
                 'sync_t_lead_b', ...
                 'leading_b', ...
                 'n_sync_intervals_total_b', ...
                 'n_sync_intervals_p_b', ...
                 'n_sync_intervals_t_b', ...
                 'tau_weighted_avg_b', ...
                 'tau_range_b', ...
                 'R2_weighted_avg_overall_b', ...
                 'R2_weighted_avg__within_b', ...
                 'abs_r_weighted_avg_overall_b', ...
                 'abs_r_weighted_avg_within_b', ...
                 'sync_total_h', ...
                 'sync_p_lead_h', ...
                 'sync_t_lead_h', ...
                 'leading_h', ...
                 'n_sync_intervals_total_h', ...
                 'n_sync_intervals_p_h', ...
                 'n_sync_intervals_t_h', ...
                 'tau_mean_h', ...
                 'tau_range_h', ...
                 'R2_weighted_avg_overall_h', ...
                 'R2_weighted_avg__within_h', ...
                 'abs_r_weighted_avg_overall_h', ...
                 'abs_r_weighted_avg_within_h'    });

Tab3= [Tab1 Tab2];



%% *********************************************************************
% speichern

% 
if char(directory_name(end)) ~= '\'
    
    directory_name = strcat( directory_name, '\');
    
end


disp(' ')
disp('Save results')

writetable( Tab3, ...
            strcat( directory_name, ...
                    datestr( now, 'yyyy-mm-dd' ), ...
                    '_', ...
                    'Sync_measures_of_all_files'), ...
            'FileType', ...
            'spreadsheet');

disp(' ')

