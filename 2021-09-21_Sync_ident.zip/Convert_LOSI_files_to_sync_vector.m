%% written and developed by Uwe Altmann
% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6
% Version from 11 October 2021


% Given existing LOSI files this script convert the lists into
% vectors indicating with one and zero whether at the time point of
% interest the interlocutors synchronize their movements. The resulting
% file can used to analyse the relationship between timepoint of
% snychornization and other variables, e.g. whether the tendency to
% synchronize increase during the interpersonal interaction and whether the
% tendency to synchronize depends on age of interlocutors


function [] = Convert_LOSI_files_to_sync_vector(directory_name, R2_cut_off)


%% *********************************************************************
%  parameter settings

% files
video_format = 'losi.mat';  % default is 'losi.mat'


%% *********************************************************************
%  check input arguments and select directory per hand if necessary

    % check input arguments: file name? If no, select with file browser
    if nargin<1 || isempty(directory_name) 

        disp(' ')
        disp('Please select the directory in which the LOSI files are stored.')
        
        directory_name = uigetdir;
        
    else
    
        if exist( directory_name, 'dir') ~= 7
            
            error(['The specified directory (' directory_name ...
                   ') is not a folder or does not exist.'])
        
        end
        
    end
    
    disp(' ')
    disp(['Selected directory is ' directory_name])
    disp(' ')


    % check input arguments: R2 cut off introduced by Schoenherr et al.
    % (2019) PLOSONE, doi: 10.1371/journal.pone.0211494

    if nargin<2 

        R2_cut_off = 0.25; % default = 0.25 suggested by Schoenherr et al. (2019) PLOSONE
        
        disp(' ')
        disp('Applying R2 cut off = 0.25 as suggested by Schoenherr et al. (2019, PLOSONE).')
        disp(' ')
        
    else
        
        disp(' ')
        disp(['R2 cut off = ', num2str(R2_cut_off)] )
        disp(' ')
        
    end
    
    
    
    
%% *********************************************************************
% liste der LOSI Dateien erstellen

    if isempty(video_format)
        
        disp(' ')
        error('The variable video_format is empthy, please specify a search string.')
        
    elseif video_format(1)~='*'
        
        video_format = ['*' video_format];
        
    end
    
    Names = dir( fullfile(directory_name, video_format) );
    Names = {Names.name}';
    Names = fullfile(directory_name, Names);

    n_videos = length(Names);
    
    disp(' ')
    disp(['Found ' num2str(n_videos) ' files.'])




%% *********************************************************************
% losi laden und Kennwerte berechnen

    % vector für alle Sync Werte 
    sync_vec_all = double.empty(0, 7);

    % vector für alle Dateinamen
    file_names_vec_all = {};

    
    
    for n = 1:n_videos
        
        % store directory, file name and file suffix in separate variables
        [~, data_file_name, ~] = fileparts(Names{n});
        
        
        % load data
        disp(' ')
        disp(' ')
        disp(['Load LOSI file ' ...
              '(' num2str(n) ' of ' num2str(n_videos) ...
              '): ' Names{n}]);

        load( Names{n} , 'data_file_name', ...
             'time_series_length', ...
             'losi_body', 'losi_head');
        
        
        % applying R2 cut off according to Schoenherr et al 2019 PLOSONE
        losi_body( losi_body(:,4) < R2_cut_off, : ) = [];
        losi_head( losi_head(:,4) < R2_cut_off, : ) = [];
         
        
        % define matrix for sync vectors for the specific LOSI file
        % 1 col: time point
        % 2 col: on-off-pattern - sync total - body 
        % 3 col: on-off-pattern - sync person 1 lead - body 
        % 4 col: on-off-pattern - sync person 2 lead - body 
        % 5 col: on-off-pattern - sync total - head 
        % 6 col: on-off-pattern - sync person 1 lead - head
        % 7 col: on-off-pattern - sync person 2 lead - head 
        sync_vec = zeros( time_series_length, 7);
        
        
        
        % 1 col: time point
        sync_vec(:,1) = (1:time_series_length)';
        
        
        % --- BODY ---
        disp(' ')
        disp('Compute for on-off-pattern of synchronisation -> body')
        
        
        for n2 = 1: length( losi_body(:,1) )
            
            sync_vec( losi_body(n2,2):losi_body(n2,3), 2) = 1 ;
            
            if losi_body(n2,1) > 0
                
                sync_vec( losi_body(n2,2):losi_body(n2,3), 3) = 1 ;
                
            elseif losi_body(n2,1) < 0
                
                sync_vec( losi_body(n2,2):losi_body(n2,3), 4) = 1 ;
                
            end
            
        end
        
        
        
        % --- HEAD ---
        disp(' ')
        disp('Compute for on-off-pattern of synchronisation -> head')
        
        
        for n2 = 1: length( losi_head(:,1) )
            
            sync_vec( losi_head(n2,2):losi_head(n2,3), 5) = 1 ;
            
            if losi_head(n2,1) > 0
                
                sync_vec( losi_head(n2,2):losi_head(n2,3), 6) = 1 ;
                
            elseif losi_head(n2,1) < 0
                
                sync_vec( losi_head(n2,2):losi_head(n2,3), 7) = 1 ;
                
            end
            
        end
        
        
        % store matrix of specific file in "overall" matrix
        sync_vec_all = [ sync_vec_all ; sync_vec ];
        
        % file name as vector
        file_names_vec = cell(time_series_length,1);
        file_names_vec(:) = cellstr(data_file_name);

        file_names_vec_all = [ file_names_vec_all ; file_names_vec ];
        

    end % for

    
    
    
    
%% *********************************************************************
% Dateinamen und Statistken in einer Tabelle zusammenfassen

Tab1 = cell2table( file_names_vec_all , 'VariableNames', {'file_name'});

Tab2 = array2table(sync_vec_all, ...
            'VariableNames', ...
                {'time_point', ...
                 'sync_total_b', ...
                 'sync_p_lead_b', ...
                 'sync_t_lead_b', ...
                 'sync_total_h', ...
                 'sync_p_lead_h', ...
                 'sync_t_lead_h' });

Tab3= [Tab1 Tab2];



%% *********************************************************************
% speichern

% 
if char(directory_name(end)) ~= '\'
    
    directory_name = strcat( directory_name, '\');
    
end


disp(' ')
disp('Save results')
      
writetable( Tab3, ...
            strcat( directory_name, ...
                    datestr( now, 'yyyy-mm-dd' ), ...
                    '_', ...
                    'Sync_vector_of_all_files.txt')  );
        
disp(' ')

