%% written and developed by Uwe Altmann
%% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6


function [] = Merge_all_LOSI_files_in_the_directory(directory_name)


%% *********************************************************************
%  parameter settings

% files
video_format = 'losi.mat';  % default is 'losi.mat'


%% *********************************************************************
%  check input arguments and select directory per hand if necessary

    % check input arguments: file name? If no, select with file browser
    if nargin<1 || isempty(directory_name) ,

        disp(' ')
        disp('Please select the directory in which the motion energy files are stored.')
        
        directory_name = uigetdir;
        
    else
    
        if exist( directory_name, 'dir') ~= 7
            
            error(['The specified directory (' directory_name ...
                   ') is not a folder or does not exist.'])
        
        end
        
    end
    
    disp(' ')
    disp(['Selected directory is ' directory_name])
    disp(' ')

    
%% *********************************************************************
% liste der LOSI Dateien erstellen

    if isempty(video_format),
        
        disp(' ')
        error('The variable video_format is empthy, please specify a search string.')
        
    elseif video_format(1)~='*',
        
        video_format = ['*' video_format];
        
    end
    
    Names = dir( fullfile(directory_name, video_format) );
    Names = {Names.name}';
    Names = fullfile(directory_name, Names);

    n_videos = length(Names);
    
    disp(' ')
    disp(['Found ' num2str(n_videos) ' files.'])




%% *********************************************************************
% losi laden und Kennwerte berechnen

    stats = zeros( n_videos, 18);
    %  1 col: body sync total
    %  2 col: body sync pat
    %  3 col: body sync ther
    %  4 col: body leading 
    %  5 col: body number of sync intervals total
    %  6 col: body number of sync intervals pat
    %  7 col: body number of sync intervals thr
    %  8 col: body time lag mean
    %  9 col: body time lag range (attuement)
    
    % 10 col: head sync total
    % 11 col: head sync pat
    % 12 col: head sync ther
    % 13 col: head leading 
    % 14 col: body number of sync intervals total
    % 15 col: body number of sync intervals pat
    % 16 col: body number of sync intervals thr
    % 17 col: head time lag mean
    % 18 col: head time lag range (attuement)    

    for n = 1:n_videos,
        
        % store directory, file name and fiel suffix in separate variables
        [~, data_file_name, ~] = fileparts(Names{n});
        
        
        % load data
        disp(' ')
        disp(' ')
        disp(['Load LOSI file ' ...
              '(' num2str(n) ' of ' num2str(n_videos) ...
              '): ' Names{n}]);

        load( Names{n} , 'data_file_name', ...
             'time_series_length', ...
             'losi_body', 'losi_head');
        
        
        % 
        disp(' ')
        disp('Compute statistics about synchronisation using LOSI - body')
        
        stats(n, 1) = sum( losi_body(:,3) - losi_body(:,2) ) / time_series_length * 100;
        stats(n, 2) = sum( losi_body( losi_body(:,1) > 0,3) - losi_body(losi_body(:,1) > 0,2) ) / time_series_length * 100;
        stats(n, 3) = sum( losi_body( losi_body(:,1) < 0,3) - losi_body(losi_body(:,1) < 0,2) ) / time_series_length * 100;
        stats(n, 4) = stats(n,2) - stats(n,3) ;
        
        stats(n, 5) = length( losi_body(:, 1) );
        stats(n, 6) = length( losi_body(losi_body(:,1) > 0, 1) );
        stats(n, 7) = length( losi_body(losi_body(:,1) < 0, 1) );
        
        disp(' ')
        disp('Compute statistics about synchronisation using LOSI - head')
        
        stats(n, 8) = mean( abs(losi_body( :, 1)) );
        stats(n, 9) = max( abs(losi_body( :, 1)) ) - min( abs(losi_body( :, 1)) );

        stats(n,10) = sum( losi_head(:,3) - losi_head(:,2) ) / time_series_length * 100;
        stats(n,11) = sum( losi_head( losi_head(:,1) > 0,3) - losi_head(losi_head(:,1) > 0,2) ) / time_series_length * 100;
        stats(n,12) = sum( losi_head( losi_head(:,1) < 0,3) - losi_head(losi_head(:,1) < 0,2) ) / time_series_length * 100;
        stats(n,13) = stats(n,2) - stats(n,3) ;
        
        stats(n,14) = length( losi_head(:, 1) );
        stats(n,15) = length( losi_head(losi_head(:,1) > 0, 1) );
        stats(n,16) = length( losi_head(losi_head(:,1) < 0, 1) );
        
        stats(n,17) = mean( abs(losi_head( :, 1)) );
        stats(n,18) = max( abs(losi_head( :, 1)) ) - min( abs(losi_head( :, 1)) );
        
        
        %
        list_of_file_names{n} = data_file_name;
        
        
        %
        clear data_file_name time_series_length  ...
               losi_body losi_head ;
        
    end % for

    
%% *********************************************************************
% Dateinamen und Statistken in einer Tabelle zusammenfassen

Tab1 = cell2table(list_of_file_names' , 'VariableNames', {'file_name'});

Tab2 = array2table(stats, ...
            'VariableNames', ...
                {'sync_total_b', 'sync_p_lead_b', 'sync_t_lead_b', ...
                 'leading_b', ...
                 'n_sync_intervals_total_b', 'n_sync_intervals_p_b', 'n_sync_intervals_t_b', ...
                 'tau_mean_b', 'tau_range_b', ...                 
                 'sync_total_h', 'sync_p_lead_h', 'sync_t_lead_h', ...
                 'leading_h', ...
                 'n_sync_intervals_total_h', 'n_sync_intervals_p_h', 'n_sync_intervals_t_h', ...
                 'tau_mean_h', 'tau_range_h'    });

Tab3= [Tab1 Tab2];



%% *********************************************************************
% speichern

disp(' ')
disp('Save results')

writetable(Tab3, 'Sync_measures_of_all_files', 'FileType','spreadsheet');

disp(' ')

