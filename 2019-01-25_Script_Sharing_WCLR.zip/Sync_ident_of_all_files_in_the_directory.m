%% written and developed by Uwe Altmann
%% please cite: Altmann, U. (2013). Synchronisation nonverbalen Verhaltens. Wiesbaden: VS Springer. ISBN 978-3-531-19815-6

%% *********************************************************************
% The script searches for files with motion energy time series in a given 
% directory and apply WCLC / WCLR on it. Then it run the peak picking
% algorithm. At last all resultsing LOSI files were used to create a table
% with synchrony measures for all motion energy time series piars found in
% the directory.

function [] = Sync_ident_of_all_files_in_the_directory(directory_name)


%% *********************************************************************
%  parameter settings

% files
video_format = 'MEA_co12_stand_vef_mm_lt.txt';  % default is 'MEA_co12_stand_vef_mm_lt.txt' -> MEA with cut off=12 & standardization & video errors filtered & moving median & log transformation


% windowed cross-lagged correlation / regression

% WCLC or WCLR
method = 'WCLC'; % use 'WCLR' or 'WCLC' (default)

% set bandwidth to 125 frames (= 5 seconds if 25 fps)
bandwidth = 125; % recommanded resp. default is 125

% set maximum time lag to 5 seconds (= 125 frames if 25 fps)
max_lag = 125; % recommanded resp. default is 125

% calculate WCLR/WCLC in steps of 1
step = 1; % default is 1

% add_noise = true to avoid convergence problems with respect to the WCLR
add_noise = false;




% peak picking
minimum_length = 10; % 10 is recommended

time_lag_tolerance = 1; % default is 1




%% *********************************************************************
%  check input arguments and select directory per hand if necessary

    % check input arguments: file name? If no, select with file browser
    if nargin<1 || isempty(directory_name) ,

        disp(' ')
        disp('Please select the directory in which the motion energy files are stored.')
        
        directory_name = uigetdir;
        
    else
    
        if exist( directory_name, 'dir') ~= 7
            
            error(['The specified directory (' directory_name ...
                   ') is not a folder or does not exist.'])
        
        end
        
    end
    
    disp(' ')
    disp(['Selected directory is ' directory_name])
    disp(' ')

    
    % WCLC / WCLC
    method = upper( method );
    
    if ~(strcmp(method,'WCLC') || strcmp(method,'WCLR') ),
        
        error('Unknown value of the parameter method. It must be WCLC or WCLR.');
        
    end
    
    
    
    

%% *********************************************************************
% liste der motion energy time series pairs erstellen

    if isempty(video_format),
        
        disp(' ')
        error('The variable video_format is empthy, please specify a search string.')
        
    elseif video_format(1)~='*',
        
        video_format = ['*' video_format];
        
    end
    
    Names = dir( fullfile(directory_name, video_format) );
    Names = {Names.name}';
    Names = fullfile(directory_name, Names);

    n_videos = length(Names);
    
    disp(' ')
    disp(['Found ' num2str(n_videos) ' files.'])




%% *********************************************************************

    for n = 1:n_videos,
        
        % store directory, file name and fiel suffix in separate variables
        [data_file_path, data_file_name, ~] = fileparts(Names{n});
        
        
        % load data
        disp(' ')
        disp(['Load time series file ' ...
              '(' num2str(n) ' of ' num2str(n_videos) ...
              '): ' Names{n}]);

        data = dlmread( Names{n} );
        
        time_series_length = length(data(:,1));
        
        t = (1:time_series_length)';
        
        
        
        % WCLC / WCLR
        switch method,
            case 'WCLC',  % WCLC
                
                disp(' ')
                disp('Compute R2 with WCLC - body motions');
                
                R2_body = compute_WCLC(...
                            [t data(:,1:2)], ...
                            bandwidth, step, max_lag, add_noise);           
                
                disp(' ')
                disp('Compute R2 with WCLC - head motions');
                
                R2_head = compute_WCLC(...
                            [t data(:,5:6)], ...
                            bandwidth, step, max_lag, add_noise);   
                
                
            case 'WCLR',  % WCLR 
                
                disp(' ')
                disp('Compute R2 with WCLR - body motions');
                
                R2_body = compute_WCLR(...
                            [t data(:,1:2)], ...
                            bandwidth, step, max_lag, add_noise);           
                
                disp(' ')
                disp('Compute R2 with WCLR - head motions');
                
                R2_head = compute_WCLR(...
                            [t data(:,5:6)], ...
                            bandwidth, step, max_lag, add_noise);   
                
        end
        
        
        
        % peak picking
        disp(' ')
        disp('Applying peak picking algorithm on R2 matrix - body motions.');
        
        [losi_body] = find_all_sync_intervals_v02(R2_body, time_lag_tolerance, minimum_length);
        
       
        disp(' ')
        disp('Applying peak picking algorithm on R2 matrix - head motions.');
        
        [losi_head] = find_all_sync_intervals_v02(R2_head, time_lag_tolerance, minimum_length);
        
        
        % save list of sync intervals (LOSI)
        disp(' ')
        disp('Save list of sync intervals (LOSI).');
        disp(' ')
        
        save([data_file_path, '\', data_file_name, '_losi.mat'], ...
             'data_file_name', ...
             'time_series_length', ...
             'method', 'bandwidth', 'max_lag', 'step', ...
             'minimum_length', 'time_lag_tolerance', ...
             'losi_body', 'losi_head' );


    end % for

    disp(' ')
    disp('All time series files were analysed.');
    disp(' ')
